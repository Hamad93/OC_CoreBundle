<?php

namespace TP\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TPCoreBundle extends Bundle
{
}
